﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OtusHw16.Entities
{
    public class Orders
    {
        public int Id { get; set; }

        public int CustomerID { get; set; }

        public int ProductID { get; set; }

        public int Quantity { get; set; }
    }
}
