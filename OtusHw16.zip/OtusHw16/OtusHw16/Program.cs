﻿using Dapper;
using Npgsql;
using OtusHw16.Entities;
using System.Collections.Generic;

namespace OtusHw16
{
    internal class Program
    {
        static string conString = "Server=localhost;Port=5432;Database=shop;UserId=***; Password=***; commandTimeout=120;";
        static void Main(string[] args)
        {
            var product1 = GetProductByName("Product 1"); // Запрос 1
            var product2 = GetProductByName("Product 2");// Запрос 2
            Console.WriteLine(product1.Description);
            Console.WriteLine(product2.Description);
            var customer1 = GetCustomerByName("John"); // Запрос 1
            var customer2 = GetCustomerByName("Jane");// Запрос 2
            Console.WriteLine(customer1.LastName);
            Console.WriteLine(customer2.LastName);
            var order1 = GetOrderById(1); // Запрос 1
            var order2 = GetOrderById(2);// Запрос 2
            Console.WriteLine(product1.Description);
            Console.WriteLine(product2.Description);
            Console.WriteLine(GetCustomerProducts().Count);
        }

        static List<CustomerProduct> GetCustomerProducts() // все запросы выборки из выбранного задания с передачей параметров - таблица по  с индексом
        {
            using var con = new NpgsqlConnection(conString);
            con.Open();
            var query1 = @"
                SELECT
                c.""id"" AS CustomerID,
                c.""firstname"",
                c.""LastName"",
                p.""ID"" AS ProductID,
                o.""Quantity"" AS ProductQuantity,
                p.""Price"" AS ProductPrice
                FROM public.""customers"" c
                INNER JOIN public.""orders"" o
                ON c.""id"" = o.""CustomerID""
                INNER JOIN public.""products"" p
                ON o.""ProductID"" = p.""ID""
                WHERE c.""Age"" > 30 AND p.""ID"" = 1;";
            var result = con.Query<CustomerProduct>(query1).ToList();
            return result;
        }

        static Orders GetOrderById(int id)
        {
            using var con = new NpgsqlConnection(conString);
            con.Open();
            var query1 = "select * from public.orders where id = @orderId";
            var orders = con.QueryFirst<Orders>(query1, new { orderId = id });
            return orders;
        }

        static Customers GetCustomerByName(string name)
        {
            using var con = new NpgsqlConnection(conString);
            con.Open();
            var query1 = "select * from public.customers where firstname = @searchName";
            var customers = con.QueryFirst<Customers>(query1, new { searchName = name });
            return customers;
        }

        static Products GetProductByName(string name)
        {
            using var con = new NpgsqlConnection(conString);
            con.Open();
            var query1 = "select * from public.products where name = @searchName";
            var products = con.QueryFirst<Products>(query1, new { searchName = name });
            return products;

        }

        public class CustomerProduct
        {
            public int CustomerID { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int ProductID { get; set; }
            public int ProductQuantity { get; set; }
            public decimal ProductPrice { get; set; }
        }
    }
}